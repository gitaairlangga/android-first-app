enum UserActivitySelectionEntity {
  sedentary,
  lowActive,
  active,
  veryActive
}
