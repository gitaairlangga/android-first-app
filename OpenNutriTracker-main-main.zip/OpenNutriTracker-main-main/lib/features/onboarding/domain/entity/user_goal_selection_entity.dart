enum UserGoalSelectionEntity {
  loseWeight,
  maintainWeight,
  gainWeigh
}
