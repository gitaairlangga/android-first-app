enum UserGenderSelectionEntity {
  genderMale,
  genderFemale
}
