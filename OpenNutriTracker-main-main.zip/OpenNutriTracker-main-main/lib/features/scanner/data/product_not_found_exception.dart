class ProductNotFoundException implements Exception {}
