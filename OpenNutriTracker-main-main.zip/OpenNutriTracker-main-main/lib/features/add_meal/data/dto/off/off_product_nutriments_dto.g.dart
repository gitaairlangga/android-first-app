// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'off_product_nutriments_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OFFProductNutrimentsDTO _$OFFProductNutrimentsDTOFromJson(
        Map<String, dynamic> json) =>
    OFFProductNutrimentsDTO(
      energy_kcal_100g: json['energy-kcal_100g'],
      carbohydrates_100g: json['carbohydrates_100g'],
      fat_100g: json['fat_100g'],
      proteins_100g: json['proteins_100g'],
      sugars_100g: json['sugars_100g'],
      saturated_fat_100g: json['saturated-fat_100g'],
      fiber_100g: json['fiber_100g'],
    );

Map<String, dynamic> _$OFFProductNutrimentsDTOToJson(
        OFFProductNutrimentsDTO instance) =>
    <String, dynamic>{
      'energy-kcal_100g': instance.energy_kcal_100g,
      'carbohydrates_100g': instance.carbohydrates_100g,
      'fat_100g': instance.fat_100g,
      'proteins_100g': instance.proteins_100g,
      'sugars_100g': instance.sugars_100g,
      'saturated-fat_100g': instance.saturated_fat_100g,
      'fiber_100g': instance.fiber_100g,
    };
