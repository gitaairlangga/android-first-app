class URLConst {
  static const paCompendium2011URL =
      "https://sites.google.com/site/compendiumofphysicalactivities/home";
  static const privacyPolicyURLEn =
      "https://www.iubenda.com/privacy-policy/53501884";
  static const privacyPolicyURLDe =
      "https://www.iubenda.com/privacy-policy/53922100";
}
