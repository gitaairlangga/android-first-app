enum VerticalListPopupMenuSelections {
  onCopy,
  onDelete,
}
