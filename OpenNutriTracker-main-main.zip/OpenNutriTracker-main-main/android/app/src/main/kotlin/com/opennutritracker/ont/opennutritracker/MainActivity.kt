package com.opennutritracker.ont.opennutritracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
