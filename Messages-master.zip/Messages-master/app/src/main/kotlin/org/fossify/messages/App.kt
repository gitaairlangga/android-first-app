package org.fossify.messages

import org.fossify.commons.FossifyApp

class App : FossifyApp() {
    override val isAppLockFeatureAvailable = true
}
