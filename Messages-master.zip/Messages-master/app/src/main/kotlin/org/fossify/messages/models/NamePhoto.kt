package org.fossify.messages.models

data class NamePhoto(val name: String, val photoUri: String?)
