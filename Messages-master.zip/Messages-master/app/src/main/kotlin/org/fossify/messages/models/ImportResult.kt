package org.fossify.messages.models

enum class ImportResult {
    IMPORT_FAIL, IMPORT_OK, IMPORT_PARTIAL, IMPORT_NOTHING_NEW
}
