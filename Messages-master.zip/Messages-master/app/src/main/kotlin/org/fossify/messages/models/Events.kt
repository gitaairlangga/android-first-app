package org.fossify.messages.models

class Events {
    class RefreshMessages
}
