package org.fossify.messages.models

data class SIMCard(val id: Int, val subscriptionId: Int, val label: String)
